#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mixed-effects (random intercept + random slope):
    HR_z ~ steps_z
"""

import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
from statsmodels.stats.diagnostic import het_breuschpagan, het_white
from statsmodels.stats.stattools import durbin_watson
from scipy.stats import shapiro, kstest, norm
from statsmodels.stats.outliers_influence import variance_inflation_factor as vif
from statsmodels.graphics.gofplots import qqplot

# ---------- 설정 ----------
DATADIR = Path("/Users/jaehwayang/DSL/EDA/proc/hupa/Preprocessed")
PATTERN = "HUPA*.csv"

# ▶ 여기: Path 로 선언
OUTDIR = Path("/Users/jaehwayang/DSL/EDA/carb_hr_bg/1.step_hr/2.steps_hr_lmm")
OUTDIR.mkdir(parents=True, exist_ok=True)

HR_CANDS    = ["heart_rate", "HeartRate", "HR", "hr", "HR_bpm"]
STEPS_CANDS = ["steps", "Steps", "step", "Step", "activity_steps"]

# ---------- 유틸 ----------
def find_col(df, cands):
    cols = df.columns
    for c in cands:
        if c in cols: return c
    low = {c.lower(): c for c in cols}
    for c in cands:
        if c.lower() in low: return low[c.lower()]
    return None

def robust_read_csv(p: Path):
    try:
        df = pd.read_csv(p)
        if df.shape[1] == 1 and ";" in df.columns[0]:
            df = pd.read_csv(p, sep=";")
    except Exception:
        df = pd.read_csv(p, sep=";")
    return df

zscore = lambda s: (s - s.mean()) / s.std(ddof=0) if s.std(ddof=0) else np.nan

# ---------- 데이터 로드 ----------
frames = []
for f in DATADIR.glob(PATTERN):
    df = robust_read_csv(f)
    hr = find_col(df, HR_CANDS)
    st = find_col(df, STEPS_CANDS)
    if hr is None or st is None:
        print(f"[SKIP] {f.name}: HR/steps 열 없음", file=sys.stderr); continue

    df[hr] = pd.to_numeric(df[hr], errors="coerce").replace(0, np.nan)
    df[st] = pd.to_numeric(df[st], errors="coerce")

    g = df[[hr, st]].rename(columns={hr: "HR", st: "steps"})
    g["file"] = f.stem
    frames.append(g)

if not frames:
    sys.exit("적합할 데이터가 없습니다.")

data = pd.concat(frames, ignore_index=True)

# ---------- 표준화 & 모형 ----------
data["HR_z"]    = data.groupby("file")["HR"].transform(zscore)
data["steps_z"] = data.groupby("file")["steps"].transform(zscore)
df_model = data[["HR_z", "steps_z", "file"]].dropna()

mod = smf.mixedlm("HR_z ~ steps_z", df_model,
                  groups=df_model["file"], re_formula="~ steps_z")
fit = mod.fit(method="lbfgs", reml=False, maxiter=200)

# ---------- 결과 저장 ----------
coef = pd.DataFrame({
    "param": fit.params.index,
    "est":   fit.params.values,
    "SE":    fit.bse.values,
    "p":     fit.pvalues.values
})
sd_int  = np.sqrt(fit.cov_re.iloc[0, 0])
sd_slo  = np.sqrt(fit.cov_re.iloc[1, 1])
coef = pd.concat([coef,
    pd.DataFrame({"param":["sd_rint","sd_rslope","resid_sd"],
                  "est":[sd_int, sd_slo, np.sqrt(fit.scale)]})])
coef.to_csv(OUTDIR/"lmm_coefs.csv", index=False)

# BLUPs
re = fit.random_effects
slopes = pd.DataFrame({
    "file": re.keys(),
    "sub_intercept": [re[k][0] for k in re],
    "sub_slope":     [fit.params["steps_z"] + re[k][1] for k in re]
})
slopes.to_csv(OUTDIR/"perperson_slopes.csv", index=False)
pd.DataFrame.from_dict(re, orient="index").to_csv(
    OUTDIR/"random_effects_table.csv")

# ---------- 시각화 ----------
sample = df_model.sample(min(25000, len(df_model)), random_state=0)
plt.figure(figsize=(6,6))
plt.scatter(sample["steps_z"], sample["HR_z"], s=4, alpha=0.1)
xx = np.linspace(-3,3,200)
plt.plot(xx, fit.params["Intercept"] + fit.params["steps_z"]*xx,
         "r", lw=2, label=f"β = {fit.params['steps_z']:.2f}")
plt.xlabel("steps (z)"); plt.ylabel("HR (z)")
plt.title("HR vs steps (pooled)"); plt.legend(); plt.grid(alpha=.3)
plt.tight_layout(); plt.savefig(OUTDIR/"steps_vs_hr_scatter.png", dpi=150)
plt.close()

print(f"\n[완료] 결과 저장: {OUTDIR}\n")

# ---------- 진단 / 적합도 검정 ----------


resid  = fit.resid  # marginal residuals
fitted = fit.fittedvalues

# (A) 정규성 ────────────────────────────────
sh_p   = shapiro(resid.dropna())
ks_p   = kstest((resid - resid.mean())/resid.std(ddof=0), norm.cdf)

# (B) 등분산성 ──────────────────────────────
bp_stat, bp_p, _, _ = het_breuschpagan(resid, fit.model.exog)
w_stat , w_p , _ , _ = het_white(resid, fit.model.exog)

# (C) 독립성 ───────────────────────────────
dw = durbin_watson(resid)

# (D) 공선성(VIF) ──────────────────────────
vif_tbl = pd.DataFrame({
    "var": fit.model.exog_names,
    "VIF": [vif(fit.model.exog, i) for i in range(fit.model.exog.shape[1])]
})

# ---------- 결과 저장 ----------
diag = pd.DataFrame([{
    "Shapiro_W": sh_p.statistic, "Shapiro_p": sh_p.pvalue,
    "KS_D": ks_p.statistic,     "KS_p": ks_p.pvalue,
    "BreuschPagan_stat": bp_stat, "BP_p": bp_p,
    "White_stat": w_stat,         "White_p": w_p,
    "DurbinWatson": dw
}])
diag.to_csv(OUTDIR / "diagnostics_overall.csv", index=False)
vif_tbl.to_csv(OUTDIR / "diagnostics_VIF.csv", index=False)

# ---------- 잔차 그림 ----------
plt.figure(figsize=(6,4))
plt.scatter(fitted, resid, alpha=.3)
plt.axhline(0,c='r'); plt.xlabel("Fitted"); plt.ylabel("Residual")
plt.title("Fitted vs Residual"); plt.tight_layout()
plt.savefig(OUTDIR/"diag_fitted_resid.png", dpi=150); plt.close()

qqplot(resid, line='45', fit=True)
plt.title("Q–Q plot of residuals"); plt.tight_layout()
plt.savefig(OUTDIR/"diag_qqplot.png", dpi=150); plt.close()