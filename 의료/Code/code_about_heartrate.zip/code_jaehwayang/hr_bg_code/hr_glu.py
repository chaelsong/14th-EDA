

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compare ΔBG (15–120 min) after carb input between two groups:

Group 1 : HR(t0) > HR(t0‑15 min)   (HR rise)
Group 2 : HR(t0) ≤ HR(t0‑15 min)  (HR flat/decline)

Steps
-----
1. Load every HUPA*.csv in Preprocessed folder.
2. Detect columns: glucose (bg), heart_rate (hr), carbs (carb grams).
3. For each carb‑intake row (carbs > 0):
   - Ensure 15 min history and 120 min future exist.
   - Classify into Group 1/2 based on HR change.
   - Compute ΔBG_lag = BG(t0) – BG(t0+lag)  for lags = 15,30,…,120 min.
4. Aggregate per event → long table (file, time, group, lag, delta_bg).
5. Statistical test Group1 vs Group2 at each lag:
   - Welch t‑test, Mann‑Whitney, Cohen’s d.
6. Save:
   * event_table.csv              (one row per event×lag)
   * stats_summary.csv            (lag, n1, n2, mean1, mean2, p_t, p_u, d)
7. Two violin/box plots per lag saved as PNG.

Run
---
$ python hr_glu.py
"""

import sys, numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
from tqdm import tqdm
from scipy.stats import ttest_ind, mannwhitneyu
from sklearn.preprocessing import MinMaxScaler

# ------------ settings -------------
DATADIR = Path("/Users/jaehwayang/DSL/EDA/proc/hupa/Preprocessed")
PATTERN  = "HUPA*.csv"
OUTDIR   = Path("/Users/jaehwayang/DSL/EDA/carb_hr_bg/hr_glu_out_scaled")
OUTDIR.mkdir(parents=True, exist_ok=True)

HR_CANDS  = ["heart_rate","HR","hr"]
BG_CANDS  = ["glucose","bg","BG","BloodGlucose"]
# candidate column names for carb intake
CARB_CANDS = ["carb_input", "carbs", "CarbAmount", "carb", "CHO"]

LAGS_MIN = np.arange(15, 125, 15)       # 15‒120 min
STEP = 5                                # 5 min per row

# ------------ helpers --------------
def find_col(df, cands):
    for c in cands:
        if c in df.columns: return c
    low={c.lower():c for c in df.columns}
    for c in cands:
        if c.lower() in low: return low[c.lower()]
    return None

# ------------ load & process -------
events = []
for fp in tqdm(sorted(DATADIR.glob(PATTERN))):
    df = pd.read_csv(fp)
    if df.shape[1]==1 and ";" in df.columns[0]:
        df = pd.read_csv(fp, sep=";")
    h = find_col(df, HR_CANDS); b = find_col(df, BG_CANDS); c = find_col(df, CARB_CANDS)
    if None in (h,b,c): continue

    df[h] = pd.to_numeric(df[h], errors="coerce")
    df[b] = pd.to_numeric(df[b], errors="coerce")
    df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)
    # --- per‑file min‑max scaling for HR and BG ---
    scaler = MinMaxScaler(feature_range=(0, 1))
    df[[h, b]] = scaler.fit_transform(df[[h, b]])

    for idx in df.index[df[c] > 0]:
        t0 = idx
        t_minus3 = t0 - 3      # 15 min back (3 rows)
        t_max = t0 + 24        # 120 min ahead (24 rows)

        if t_minus3 < 0 or t_max >= len(df): continue
        if pd.isna(df.loc[[t_minus3, t0], h]).any(): continue
        if pd.isna(df.loc[[t0]+list(range(t0+3, t_max+1, 3)), b]).any(): continue

        hr_diff = df.at[t0, h] - df.at[t_minus3, h]
        group = 1 if hr_diff > 0 else 2

        bg_t0 = df.at[t0, b]

        for l in LAGS_MIN:
            step = l // STEP
            bg_future = df.at[t0 + step, b]
            d_bg = bg_t0 - bg_future
            events.append({
                "file": fp.stem,
                "idx": t0,
                "lag_min": l,
                "group": group,
                "delta_bg": d_bg
            })

# to DataFrame
events_df = pd.DataFrame(events)
events_df.to_csv(OUTDIR / "event_table.csv", index=False)

# ------------ stats summary --------
rows=[]
for l in LAGS_MIN:
    g1 = events_df[(events_df["lag_min"]==l) & (events_df["group"]==1)]["delta_bg"]
    g2 = events_df[(events_df["lag_min"]==l) & (events_df["group"]==2)]["delta_bg"]
    if len(g1)<3 or len(g2)<3: continue
    tstat,p_t = ttest_ind(g1, g2, equal_var=False, nan_policy='omit')
    u,p_u  = mannwhitneyu(g1, g2, alternative="two-sided")
    d = (g1.mean() - g2.mean()) / np.sqrt(((g1.std(ddof=1)**2)+(g2.std(ddof=1)**2))/2)
    rows.append({
        "lag_min": l,
        "n1": len(g1), "mean1": g1.mean(),
        "n2": len(g2), "mean2": g2.mean(),
        "p_t": p_t, "p_u": p_u, "cohen_d": d
    })
stats_df = pd.DataFrame(rows)
stats_df.to_csv(OUTDIR / "stats_summary.csv", index=False)

# ------------ plots ----------------
import seaborn as sns
sns.set(style="whitegrid")
for l in LAGS_MIN:
    sub = events_df[events_df["lag_min"]==l]
    if sub.empty: continue
    plt.figure(figsize=(5,4))
    sns.violinplot(x="group", y="delta_bg", data=sub, inner="quartile", palette="Set2")
    plt.title(f"ΔBG at {l} min (G1↑ HR vs G2↓/= HR)")
    plt.xlabel("Group"); plt.ylabel("ΔBG (mg/dL)")
    plt.tight_layout()
    plt.savefig(OUTDIR / f"violin_deltaBG_{l}min.png", dpi=140)
    plt.close()

print(f"\nOutputs saved to {OUTDIR}\n - event_table.csv\n - stats_summary.csv\n - violin_*.png")