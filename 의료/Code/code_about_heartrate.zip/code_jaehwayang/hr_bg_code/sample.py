#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GEE (Gaussian) with AR(1) working-correlation:
    HR_z_t0  ~  HR_z_t5 + HR_z_t10 + HR_z_t15 + HR_z_t20 + HR_z_t25 + HR_z_t30
             + steps_z_t0 + … + steps_z_t30
Cluster = patient(file), time-index = row order (5‑min spacing)

Outputs
-------
gee_summary.txt           : text summary
gee_coef_table.csv        : beta, robust SE, z, p
gee_diagnostics.csv       : QIC, scale, alpha, etc.
"""
import sys, numpy as np, pandas as pd
from pathlib import Path
import statsmodels.api as sm
import patsy
from tqdm import tqdm

# ---------- paths ----------
DATADIR = Path("/Users/jaehwayang/DSL/EDA/proc/hupa/Preprocessed")
PATTERN = "HUPA*.csv"
OUTDIR  = Path("/Users/jaehwayang/DSL/EDA/carb_hr_bg/code/gee_out")
OUTDIR.mkdir(parents=True, exist_ok=True)

HR_CANDS, STEP_CANDS = ["heart_rate","HR","hr"], ["steps","step","Steps"]
LAGS = list(range(0,7))               # 0‑30 min

# ---------- helpers ----------
find = lambda cols, cands: next((c for c in cands if c in cols), None)
z    = lambda s:(s-s.mean())/s.std(ddof=0) if s.std(ddof=0) else np.nan

# ---------- load ----------
frames=[]
for p in tqdm(sorted(DATADIR.glob(PATTERN))):
    d=pd.read_csv(p)
    if d.shape[1]==1 and ";" in d.columns[0]:
        d=pd.read_csv(p,sep=";")
    h,s = find(d.columns,HR_CANDS), find(d.columns,STEP_CANDS)
    if h is None or s is None: continue
    d[h]=pd.to_numeric(d[h],errors="coerce").replace(0,np.nan)
    d[s]=pd.to_numeric(d[s],errors="coerce")
    g=d[[h,s]].rename(columns={h:"HR",s:"steps"})
    g["file"]=p.stem
    frames.append(g)

df=pd.concat(frames).dropna().reset_index(drop=True)
df["HR_z_t0"]    = df.groupby("file")["HR"].transform(z)
df["steps_z_t0"] = df.groupby("file")["steps"].transform(z)

for k in LAGS[1:]:
    lbl=f"t{5*k}"
    df[f"HR_z_{lbl}"]    = df.groupby("file")["HR_z_t0"].shift(k)
    df[f"steps_z_{lbl}"] = df.groupby("file")["steps_z_t0"].shift(k)

df = df.dropna()
# ---- explicit time index within each patient for AR(1) ----
df["time_idx"] = df.groupby("file").cumcount()

# ---------- design matrices ----------
hr_terms = " + ".join([f"HR_z_t{5*k}" for k in LAGS[1:]])
st_terms = " + ".join([f"steps_z_t{5*k}" for k in LAGS])
formula  = f"HR_z_t0 ~ {hr_terms} + {st_terms}"

y, X = patsy.dmatrices(formula, df, return_type="dataframe")
groups = df["file"].values

# ---------- GEE with Independence cov + HAC robust SE ----------
gee = sm.GEE(y, X,
             groups=groups,
             family=sm.families.Gaussian(),
             cov_struct=sm.cov_struct.Independence())
res = gee.fit()

# HAC (Newey–West) robust covariance, 5 lags ≈ 25 min
from statsmodels.stats.sandwich_covariance import cov_hac
hac = cov_hac(res, nlags=5)
res.cov_params_default = hac
res.bse = np.sqrt(np.diag(hac))

# ---------- save ----------
with open(OUTDIR/"gee_summary.txt","w") as f:
    f.write(res.summary().__str__())

coef_tbl = pd.DataFrame({
    "term": X.columns,
    "beta": res.params,
    "robust_se": res.bse,
    "z": res.z_values,
    "p": res.pvalues
})
coef_tbl.to_csv(OUTDIR/"gee_coef_table.csv", index=False)

pd.DataFrame([{
    "QIC": res.qic(),
    "scale": res.scale,
    "alpha_AR1": res.cov_struct.dep_params[0]
}]).to_csv(OUTDIR/"gee_diagnostics.csv", index=False)

print(f"GEE Independence + HAC done; QIC = {res.qic():.2f}")
print(f"GEE done → results in {OUTDIR}")

# ---------- diagnostics: normality & fitted-vs-residual ----------
from statsmodels.graphics.gofplots import qqplot
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.diagnostic import het_breuschpagan
from scipy.stats import shapiro, kstest, norm
import matplotlib.pyplot as plt

resid_resp = res.resid_response    # raw residuals
fitted_vals = res.fittedvalues

# Shapiro-Wilk
sh_w, sh_p = shapiro(resid_resp)
# Kolmogorov-Smirnov vs N(0,1)
ks_D, ks_p = kstest((resid_resp - resid_resp.mean())/resid_resp.std(ddof=0), norm.cdf)
# DW (approx for GEE)
dw = durbin_watson(resid_resp)
# BP heteroscedasticity
bp_stat, bp_p, _, _ = het_breuschpagan(resid_resp, X)

pd.DataFrame([{
    "Durbin_Watson": dw,
    "Shapiro_W": sh_w, "Shapiro_p": sh_p,
    "KS_D": ks_D, "KS_p": ks_p,
    "BP_stat": bp_stat, "BP_p": bp_p
}]).to_csv(OUTDIR / "gee_diagnostics_overall.csv", index=False)

# QQ plot
qqplot(resid_resp, line="45", fit=True)
plt.tight_layout()
plt.savefig(OUTDIR / "gee_diag_QQ.png", dpi=150)
plt.close()

# fitted vs residual
plt.figure(figsize=(6,4))
plt.scatter(fitted_vals, resid_resp, s=6, alpha=0.2)
plt.axhline(0, color='red')
plt.xlabel("Fitted"); plt.ylabel("Residual")
plt.title("GEE: Fitted vs Residual")
plt.tight_layout()
plt.savefig(OUTDIR / "gee_fitted_resid.png", dpi=150)
plt.close()

# ---------- coefficient forest plots ----------
# HR lag coefficients (exclude t0)
hr_lags = coef_tbl[coef_tbl["term"].str.match(r"HR_z_t\d+") & (coef_tbl["term"] != "HR_z_t0")].copy()
hr_lags["lag"] = hr_lags["term"].str.extract(r"t(\d+)").astype(int)

# Steps lag coefficients
st_lags = coef_tbl[coef_tbl["term"].str.match(r"steps_z_t\d+")].copy()
st_lags["lag"] = st_lags["term"].str.extract(r"t(\d+)").astype(int)

def forest(df, title, fname):
    if df.empty: return
    df = df.sort_values("lag")
    plt.figure(figsize=(6,4))
    plt.errorbar(df["lag"], df["beta"], yerr=1.96*df["robust_se"], fmt='o')
    plt.axhline(0, color='gray', ls='--')
    plt.xlabel("Lag (min)"); plt.ylabel("Coef (SD/SD)")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(OUTDIR / fname, dpi=150)
    plt.close()

forest(hr_lags, "GEE: HR autoregressive effects (0-30 min)", "gee_ext_effect_HR.png")
forest(st_lags, "GEE: Steps→HR effects (0-30 min)", "gee_ext_effect_steps.png")

print("Extra outputs saved:\n  - gee_diagnostics_overall.csv\n  - gee_diag_QQ.png / gee_fitted_resid.png\n  - gee_ext_effect_HR.png / gee_ext_effect_steps.png")
