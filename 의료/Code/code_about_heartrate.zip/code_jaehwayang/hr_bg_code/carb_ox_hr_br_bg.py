#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mixed‑effects regression of ΔBG on
    • heart‑rate (HR)
    • **Active Insulin (AI)** (instantaneous insulin‑on‑board)

Active‑insulin is computed on the fly from the per‑row insulin dose using an
exponential decay kernel (τ = 60 min, timestep = 5 min).

Steps
-----
1. Load every HUPA*.csv under `ins_proc`.
2. Detect columns (case‑insensitive):
       HR   – heart_rate …
       INS  – insulin / basal_rate … (dose per 5‑min slot)
       BG   – glucose / BloodGlucose …
3. Compute `active_insulin` forward recursion:
       AI[t] = AI[t-1]·exp(-Δt/τ) + dose[t]
4. Per‑patient z‑score scaling of HR, AI, BG.
5. ΔBG_z = BG_z(t) − BG_z(t-1).
6. Pooled OLS  +  MixedLM (random intercept + random slopes HR_z, AI_z).
7. Lag loop (5–120 min) → MixedLM per lag, table & coeff plot.

Outputs (folder `hr_ai_glu_out/`)
---------------------------------
  * ai_event_lag_coeffs.csv   – lag‑wise HR, AI coeffs
  * lmm_summary.txt / lmm_R2.csv
  * coeff_profile.png  (HR, AI vs lag)
"""

import sys, numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
from tqdm import tqdm
import statsmodels.formula.api as smf

# ------------ paths -------------
DATADIR = Path("/Users/jaehwayang/DSL/EDA/proc/hupa/ins_proc")
PATTERN = "HUPA*.csv"
OUTDIR  = Path("/Users/jaehwayang/DSL/EDA/carb_hr_bg/hr_ai_glu_out")
OUTDIR.mkdir(parents=True, exist_ok=True)

HR_COLS  = ["heart_rate","HeartRate","HR","hr"]
INS_COLS = ["insulin","Insulin","basal_rate","BasalRate","basal","BR","br"]
BG_COLS  = ["glucose","BloodGlucose","bg","BG"]

DT_MIN  = 5
TAU_MIN = 60
DECAY   = np.exp(-DT_MIN / TAU_MIN)

# ------------ helpers -----------
find = lambda df, cands: next((c for c in cands if c in df.columns or c.lower() in [x.lower() for x in df.columns]), None)

def zscore(s):
    m, sd = s.mean(), s.std(ddof=0)
    return (s-m)/sd if sd>0 else np.nan

frames=[]
for fp in tqdm(sorted(DATADIR.glob(PATTERN))):
    df = pd.read_csv(fp)
    if df.shape[1]==1 and ";" in df.columns[0]:
        df = pd.read_csv(fp, sep=";")
    h = find(df, HR_COLS); i = find(df, INS_COLS); b = find(df, BG_COLS)
    if None in (h,i,b):
        print(f"[SKIP] {fp.stem}: missing cols", file=sys.stderr); continue

    df[[h,i,b]] = df[[h,i,b]].apply(pd.to_numeric, errors='coerce')
    df = df.dropna(subset=[h,i,b]);
    if df.empty: continue

    # --- active insulin recursion ---
    dose = df[i].fillna(0).values
    ai = np.zeros_like(dose, dtype=float)
    for t in range(1,len(dose)):
        ai[t] = ai[t-1]*DECAY + dose[t]
    df["AI"] = ai

    # --- per‑file z‑score scaling ---
    for col,new in [(h,"HR_z"),("AI","AI_z"),(b,"BG_z")]:
        df[new] = zscore(df[col])

    df["file"] = fp.stem
    df["DBG_z"] = df.groupby("file")["BG_z"].diff()
    df = df.dropna(subset=["DBG_z","HR_z","AI_z"])
    frames.append(df[["HR_z","AI_z","BG_z","DBG_z","file"]])

if not frames:
    sys.exit("No data after preprocessing")

data = pd.concat(frames, ignore_index=True)

# ---------- lag MixedLM ----------
lag_results=[]
for step in range(1,25):  # 5–120 min
    lag_min = step*5
    col=f"DBG{lag_min}_z"
    data[col] = data.groupby("file")["BG_z"].shift(-step)
    data[col] = data["BG_z"] - data[col]
    sub=data.dropna(subset=[col])
    if sub.empty: continue
    mod=smf.mixedlm(f"{col} ~ HR_z + AI_z", sub, groups=sub["file"], re_formula="~ HR_z + AI_z").fit(method="lbfgs", reml=False, maxiter=200)
    lag_results.append({
        "lag_min":lag_min,
        "beta_HR":mod.params.get("HR_z",np.nan),
        "se_HR":mod.bse.get("HR_z",np.nan),
        "p_HR":mod.pvalues.get("HR_z",np.nan),
        "beta_AI":mod.params.get("AI_z",np.nan),
        "se_AI":mod.bse.get("AI_z",np.nan),
        "p_AI":mod.pvalues.get("AI_z",np.nan),
        "R2":np.nan,
        "n_obs":int(mod.nobs)
    })
lag_df=pd.DataFrame(lag_results)
lag_df.to_csv(OUTDIR/"ai_event_lag_coeffs.csv",index=False)

# ---------- baseline MixedLM (no lag) ----------
mix=smf.mixedlm("DBG_z ~ HR_z + AI_z", data, groups=data["file"], re_formula="~ HR_z + AI_z")
fit=mix.fit(method="lbfgs", reml=False, maxiter=300)
with open(OUTDIR/"lmm_summary.txt","w") as f: f.write(fit.summary().as_text())

# Nakagawa R²
sd_int=np.sqrt(fit.cov_re.iloc[0,0]); var_rnd=sd_int**2; var_res=fit.scale
X=fit.model.exog; yhat=X@fit.fe_params.values; var_fix=np.var(yhat,ddof=X.shape[1])
marR2=var_fix/(var_fix+var_rnd+var_res); conR2=(var_fix+var_rnd)/(var_fix+var_rnd+var_res)
pd.DataFrame([{"marginal_R2":marR2,"conditional_R2":conR2}]).to_csv(OUTDIR/"lmm_R2.csv",index=False)

# ---------- coeff profile plot ----------
if not lag_df.empty:
    import matplotlib.pyplot as plt
    plt.figure(figsize=(6,4))
    plt.errorbar(lag_df.lag_min, lag_df.beta_HR, yerr=1.96*lag_df.se_HR, marker='o', label='HR coeff')
    plt.errorbar(lag_df.lag_min, lag_df.beta_AI, yerr=1.96*lag_df.se_AI, marker='s', label='AI coeff')
    plt.axhline(0, c='gray', ls='--'); plt.xlabel('Lag (min)'); plt.ylabel('Coef (ΔBG scale)')
    plt.title('MixedLM coefficients vs lag'); plt.legend(); plt.tight_layout()
    plt.savefig(OUTDIR/"coeff_profile.png", dpi=140); plt.close()

print("Finished →", OUTDIR)
