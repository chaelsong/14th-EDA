#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Linear regression (mixed-effects optional) to predict glucose using
  • heart-rate (HR)
  • basal-rate insulin delivery (BR)

Assumptions
-----------
* One CSV per patient under `/proc/hupa/Preprocessed/` (same as before).
* Columns (case-insensitive):
     HR  : heart_rate / hr / HeartRate …
     BR  : basal_rate / BasalRate / br …
     BG  : glucose / bg / BloodGlucose …

What the script does
--------------------
1. Load all CSVs and detect the three columns.
2. Drop rows with missing BG, HR, or BR; min-max scale each variable **per patient**.
3. Build a tidy dataframe with [BG_z, HR_z, BR_z, file].
4. Fit two models:
     (A) Pooled OLS: BG_z ~ HR_z + BR_z.
     (B) Mixed effects (random intercept by file): BG_z ~ HR_z + BR_z.
5. Save tables with coefficients & model metrics; print console summaries.

Outputs (default folder: `hr_br_glu_out/`)
-----------------------------------------
  * ols_coefs.csv           – β, SE, p for pooled OLS
  * lmm_coefs.csv           – fixed β + random SD for MixedLM
  * model_metrics.csv       – R², AIC/BIC for both models
  * scatter_hr_bg.png       – BG vs HR (pooled) with OLS fit
  * scatter_br_bg.png       – BG vs BR (pooled) with OLS fit
"""

import sys, numpy as np, pandas as pd, matplotlib.pyplot as plt
import matplotlib
from pathlib import Path
from tqdm import tqdm
import statsmodels.formula.api as smf

# ---------- paths ----------
DATADIR = Path("/Users/jaehwayang/DSL/EDA/proc/hupa/ins_proc")
PATTERN = "HUPA*.csv"
OUTDIR  = Path("/Users/jaehwayang/DSL/EDA/carb_hr_bg/hr_br_glu_out")
OUTDIR.mkdir(parents=True, exist_ok=True)

HR_COLS = ["heart_rate","HeartRate","HR","hr"]
BR_COLS = ["basal_rate","BasalRate","basal","BR","br", 'insulin']
BG_COLS = ["glucose","BloodGlucose","bg","BG"]
CARB_COLS = ["carb_input", "carbs", "CarbAmount", "CHO"]

# ---------- helpers ----------
def find_col(df, cands):
    for c in cands:
        if c in df.columns: return c
    low = {c.lower(): c for c in df.columns}
    for c in cands:
        if c.lower() in low: return low[c.lower()]
    return None

frames = []
for fp in tqdm(sorted(DATADIR.glob(PATTERN))):
    df = pd.read_csv(fp)
    if df.shape[1] == 1 and ";" in df.columns[0]:
        df = pd.read_csv(fp, sep=";")

    h   = find_col(df, HR_COLS)
    br  = find_col(df, BR_COLS)
    bg  = find_col(df, BG_COLS)
    carb= find_col(df, CARB_COLS)

    if None in (h, br, bg, carb):
        print(f"[SKIP] {fp.name}: required column not found", file=sys.stderr)
        continue

    df[[h, br, bg]] = df[[h, br, bg]].apply(pd.to_numeric, errors="coerce")
    df = df.dropna(subset=[h, br, bg])
    if df.empty:
        continue

    # include carbs column, convert to numeric (NaN→0) 
    df[carb] = pd.to_numeric(df[carb], errors="coerce").fillna(0)

    # ---- keep only rows AT or AFTER a carb intake (>0) ----
    if (df[carb] > 0).any():
        first_carb_idx = df.index[df[carb] > 0][0]
        df = df.loc[first_carb_idx:]          # slice from first carb event onward
    else:
        continue    # no carb event → skip this file entirely
    
    # --- per‑file z‑score scaling ---
    for col in [h, br, bg]:
        mu  = df[col].mean()
        sd  = df[col].std(ddof=0)
        df[col] = (df[col] - mu) / sd if sd > 0 else np.nan

    # create scaled columns
    df["HR_z"] = df[h]
    df["BR_z"] = df[br]
    df["BG_z"] = df[bg]

    # tag patient id first
    df["file"] = fp.stem

    # ΔBG (scaled) = BG_z(t) − BG_z(t-1 step); compute within each patient
    df["DBG_z"] = df.groupby("file")["BG_z"].diff()
    # drop first NaN diff rows
    df = df.dropna(subset=["DBG_z"])

    sub = df[["HR_z", "BR_z", "BG_z", "DBG_z"]].copy()   # keep BG_z for lag shifts
    sub["file"] = df["file"]
    if not sub.empty:
        frames.append(sub)

if not frames:
    sys.exit("No usable data.")

data = pd.concat(frames, ignore_index=True)

# ---------- multi‑lag regression (15–120 min) ----------
results = []  # collect per-lag regression outputs
# 1..24 steps  == 5,10,…,120 min
LAGS_STEPS = list(range(1, 25))      # 1..24 (every 5 min)
for k in LAGS_STEPS:
    col = f"DBG{5*k}_z"
    data[col] = data.groupby("file")["BG_z"].shift(-k)  # BG_z at +lag
    data[col] = data["BG_z"] - data[col]                # ΔBG_lag
    sub = data.dropna(subset=[col])

    if sub.empty: continue
    mod = smf.mixedlm(f"{col} ~ HR_z + BR_z",
                      data=sub,
                      groups=sub["file"]).fit(method="lbfgs", reml=False, maxiter=200)
    results.append({
        "lag_min": 5*k,
        "beta_HR":  mod.params.get("HR_z", np.nan),
        "se_HR":    mod.bse.get("HR_z", np.nan),
        "p_HR":     mod.pvalues.get("HR_z", np.nan),
        "beta_BR":  mod.params.get("BR_z", np.nan),
        "se_BR":    mod.bse.get("BR_z", np.nan),
        "p_BR":     mod.pvalues.get("BR_z", np.nan),
        "intercept":mod.params.get("Intercept", np.nan),
        "R2":       mod.rsquared if hasattr(mod, 'rsquared') else np.nan,
        "n_obs":    int(mod.nobs)
    })

# save lag coefficients table
lag_df = pd.DataFrame(results)
lag_df.to_csv(OUTDIR / "lag_coeffs.csv", index=False)

# ---------- pooled OLS ----------
ols = smf.ols("DBG_z ~ HR_z + BR_z", data=data).fit()
ols_df = ols.summary2().tables[1]
ols_df.to_csv(OUTDIR/"ols_coefs.csv")

# ---------- MixedLM (random intercept + slopes) ----------
try:
    # random intercept + random slopes (HR_z, BR_z)  – 25 patients
    lmm = smf.mixedlm("DBG_z ~ HR_z + BR_z",
                      data=data,
                      groups=data["file"],
                      re_formula="~ HR_z + BR_z")
    lmm_fit = lmm.fit(method="lbfgs", reml=False, maxiter=300)
    lmm_df = pd.DataFrame({
        "param": lmm_fit.params.index,
        "estimate": lmm_fit.params.values,
        "SE": lmm_fit.bse.values,
        "p": lmm_fit.pvalues.values
    })
    lmm_df.to_csv(OUTDIR/"lmm_coefs.csv", index=False)

    # save full text summary
    with open(OUTDIR / "lmm_summary.txt", "w") as fsum:
        fsum.write(lmm_fit.summary().as_text())

    # Nakagawa R²
    sd_int = np.sqrt(lmm_fit.cov_re.iloc[0, 0])
    var_random = sd_int**2
    var_resid  = lmm_fit.scale
    X = lmm_fit.model.exog
    yhat = X @ lmm_fit.fe_params.values
    var_fixed = np.var(yhat, ddof=X.shape[1])
    marginal_R2   = var_fixed / (var_fixed + var_random + var_resid)
    conditional_R2 = (var_fixed + var_random) / (var_fixed + var_random + var_resid)

    pd.DataFrame([{
        "marginal_R2": marginal_R2,
        "conditional_R2": conditional_R2
    }]).to_csv(OUTDIR / "lmm_R2.csv", index=False)

except Exception as e:
    print("MixedLM failed:", e)
    lmm_fit = None
    marginal_R2 = np.nan

# ---------- metrics ----------
metrics = {
    "model": ["OLS", "MixedLM" if lmm_fit is not None else "MixedLM (fail)"],
    "AIC": [ols.aic, lmm_fit.aic if lmm_fit is not None else np.nan],
    "BIC": [ols.bic, lmm_fit.bic if lmm_fit is not None else np.nan],
    "R2": [ols.rsquared, marginal_R2]
}
pd.DataFrame(metrics).to_csv(OUTDIR/"model_metrics.csv", index=False)

# ---------- quick scatter plots ----------
plt.figure(figsize=(5,4))
plt.scatter(data["HR_z"], data["DBG_z"], s=4, alpha=.2)
res_pred = ols.params["Intercept"] + ols.params["HR_z"]*np.linspace(0,1,100)
plt.plot(np.linspace(0,1,100), res_pred, color="red")
plt.xlabel("HR (scaled)"); plt.ylabel("ΔBG (scaled)");
plt.title("ΔBG vs HR with OLS fit"); plt.tight_layout()
plt.savefig(OUTDIR/"scatter_hr_bg.png", dpi=140); plt.close()

plt.figure(figsize=(5,4))
plt.scatter(data["BR_z"], data["DBG_z"], s=4, alpha=.2)
res_pred2 = ols.params["Intercept"] + ols.params["BR_z"]*np.linspace(0,1,100)
plt.plot(np.linspace(0,1,100), res_pred2, color="red")
plt.xlabel("Basal rate (scaled)"); plt.ylabel("ΔBG (scaled)")
plt.title("ΔBG vs Basal-rate with OLS fit"); plt.tight_layout()
plt.savefig(OUTDIR/"scatter_br_bg.png", dpi=140); plt.close()

# ---------- coefficient profiles plot ----------
if lag_df.empty:
    lag_df = pd.DataFrame({"lag_min":[], "beta_HR":[], "se_HR":[], "beta_BR":[], "se_BR":[]})

plt.figure(figsize=(6,4))
plt.errorbar(lag_df["lag_min"], lag_df["beta_HR"],
             yerr=1.96*lag_df["se_HR"], label="HR coeff", marker='o')
plt.errorbar(lag_df["lag_min"], lag_df["beta_BR"],
             yerr=1.96*lag_df["se_BR"], label="Basal-rate coeff", marker='s')
plt.axhline(0, color='gray', ls='--')
plt.xlabel("Lag (min)"); plt.ylabel("Coefficient (ΔBG scale)")
plt.title("OLS coefficients vs lag")
plt.legend(); plt.tight_layout()
plt.savefig(OUTDIR / "coeff_profile.png", dpi=140)
plt.close()

# ---------- HR‑only coefficient plot (lags ≤ 60 min) ----------
hr_df = lag_df[lag_df["lag_min"] <= 60].copy()

if hr_df.empty:
    # nothing to plot – create an empty placeholder
    hr_df = pd.DataFrame({"lag_min": [], "beta_HR": [], "se_HR": []})

plt.figure(figsize=(6,4))
plt.errorbar(hr_df["lag_min"],
             hr_df["beta_HR"],
             yerr=1.96 * hr_df["se_HR"],
             marker='o', color='#1f77b4')
plt.axhline(0, color='gray', ls='--')
plt.xlabel("Lag (min)")
plt.ylabel("HR coefficient (ΔBG scale)")
plt.title("HR effect on ΔBG vs lag ≤ 60 min (MixedLM)")
plt.tight_layout()
plt.savefig(OUTDIR / "coeff_hr_only.png", dpi=140)
plt.close()

print("Done →", OUTDIR)
