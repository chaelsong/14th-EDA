#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ARX-LMM  (random intercept by patient)
    HR_z_t0  ~  HR_z_t5 + HR_z_t10 + HR_z_t15
             +  steps_z_t0 + … + steps_z_t15
+ 진단(Shapiro, Breusch-Pagan, DW, VIF, Q–Q plot, 잔차 vs 적합).
"""

import sys, numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
import statsmodels.formula.api as smf
from statsmodels.stats.diagnostic import het_breuschpagan, het_white
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.outliers_influence import variance_inflation_factor as vif
from statsmodels.graphics.gofplots import qqplot
from scipy.stats import chi2, shapiro, kstest, norm
from tqdm import tqdm

# ---------- 설정 ----------
DATADIR = Path("/Users/jaehwayang/DSL/EDA/proc/hupa/Preprocessed")
PATTERN  = "HUPA*.csv"
OUTDIR   = Path("/Users/jaehwayang/DSL/EDA/carb_hr_bg/1.step_hr/1.step_lag_hr")
OUTDIR.mkdir(parents=True, exist_ok=True)

HR_CANDS    = ["heart_rate","HeartRate","HR","hr"]
STEPS_CANDS = ["steps","Steps","step","Step","ActivitySteps"]
TIME_CANDS  = ["time","Time","timestamp","Timestamp","datetime","Datetime"]

# ---------- util ----------
def find_col(df, cands):
    for c in cands:
        if c in df.columns: return c
    low = {c.lower():c for c in df.columns}
    for c in cands:
        if c.lower() in low: return low[c.lower()]
    return None
def robust_read_csv(p):                         # ; 구분자 대응
    try:
        df = pd.read_csv(p)
        if df.shape[1]==1 and ";" in df.columns[0]:
            df = pd.read_csv(p, sep=";")
    except:  df = pd.read_csv(p, sep=";")
    return df
z = lambda s: (s-s.mean())/s.std(ddof=0) if s.std(ddof=0) else np.nan

# ---------- load ----------
frames=[]
for fp in tqdm(sorted(DATADIR.glob(PATTERN))):
    df = robust_read_csv(fp)
    h = find_col(df, HR_CANDS); s = find_col(df, STEPS_CANDS)
    if h is None or s is None:
        print(f"[SKIP]{fp.name}: 열 없음", file=sys.stderr); continue
    for c in (h,s): df[c]=pd.to_numeric(df[c],errors='coerce')
    df.loc[df[h]==0,h]=np.nan
    g=df[[h,s]].rename(columns={h:"HR",s:"steps"})
    g["file"]=fp.stem; frames.append(g)
if not frames: sys.exit("데이터 없음")

data = pd.concat(frames).reset_index(drop=True)
data["HR_z_t0"]    = data.groupby("file")["HR"].transform(z)
data["steps_z_t0"] = data.groupby("file")["steps"].transform(z)

# ---- lag build (5,10,15 min = 1,2,3 step) ----
for k,label in zip((1,2,3),("t5","t10","t15")):
    data[f"HR_z_{label}"]    = data.groupby("file")["HR_z_t0"].shift(k)
    data[f"steps_z_{label}"] = data.groupby("file")["steps_z_t0"].shift(k)

cols = ["HR_z_t0","file",
        "HR_z_t5","HR_z_t10","HR_z_t15",
        "steps_z_t0","steps_z_t5","steps_z_t10","steps_z_t15"]
dfm  = data[cols].dropna()

# ---------- mixed model ----------
# (1) 모델 정의
formula = ("HR_z_t0 ~ HR_z_t5 + HR_z_t10 + HR_z_t15 + "
           "steps_z_t0 + steps_z_t5 + steps_z_t10 + steps_z_t15")

# 랜덤절편 + 랜덤슬로프(HR_z_t5, steps_z_t0)  ← 수정됨
mdl = smf.mixedlm(formula, dfm,
                  groups=dfm["file"],
                  re_formula="~ HR_z_t5 + steps_z_t0")

# --- fit model first ---
fit = mdl.fit(method="lbfgs", reml=False, maxiter=200)
print("\nRandom effects structure: intercept + slopes for HR_z_t5 and steps_z_t0\n")

print(fit.summary())

# ---------- 저장: 계수 ----------
tbl = pd.DataFrame({
    "term":fit.params.index,
    "coef":fit.params.values,
    "SE":fit.bse.values,
    "p":fit.pvalues.values
})
tbl.to_csv(OUTDIR/"coefs.csv",index=False)

# ---------- 진단 ----------
resid, fitted = fit.resid, fit.fittedvalues

# 정규성
sh_w, sh_p = shapiro(resid)
ks_D, ks_p = kstest((resid-resid.mean())/resid.std(ddof=0), norm.cdf)
# 등분산
bp_s,bp_p,_,_=het_breuschpagan(resid, fit.model.exog)
white_s,white_p,_,_=het_white(resid, fit.model.exog)
# 독립성
dw = durbin_watson(resid)

diag = pd.DataFrame([{
    "Shapiro_W":sh_w,"Shapiro_p":sh_p,
    "KS_D":ks_D,"KS_p":ks_p,
    "BP_stat":bp_s,"BP_p":bp_p,
    "White_stat":white_s,"White_p":white_p,
    "DurbinWatson":dw
}])
diag.to_csv(OUTDIR/"diagnostics_overall.csv",index=False)

# VIF
vif_tbl = pd.DataFrame({
    "var":fit.model.exog_names,
    "VIF":[vif(fit.model.exog,i) for i in range(fit.model.exog.shape[1])]
})
vif_tbl.to_csv(OUTDIR/"diagnostics_VIF.csv",index=False)

# ---------- diagnostic plots ----------
plt.figure(figsize=(6,4))
plt.scatter(fitted, resid, alpha=.2,s=8)
plt.axhline(0,c='r'); plt.xlabel("Fitted"); plt.ylabel("Residual")
plt.title("Fitted vs Residual"); plt.tight_layout()
plt.savefig(OUTDIR/"diag_fitted_resid.png",dpi=150); plt.close()

qqplot(resid, line="45",fit=True); plt.tight_layout()
plt.savefig(OUTDIR/"diag_QQ.png",dpi=150); plt.close()

# ---------- 효과 그림 ----------
def effect_plot(terms, labels, fname, title, ylabel):
    ef = tbl[tbl.term.isin(terms)].copy()
    ef["lag"]=[0,5,10,15] if "0" in terms[0] else [5,10,15]
    ef.sort_values("lag",inplace=True)
    ef["lo"]=ef["coef"]-1.96*ef["SE"]; ef["hi"]=ef["coef"]+1.96*ef["SE"]
    plt.figure(figsize=(6,4))
    plt.plot(ef["lag"],ef["coef"],marker='o')
    plt.fill_between(ef["lag"],ef["lo"],ef["hi"],alpha=.2)
    plt.axhline(0,c='k',ls='--'); plt.xticks(ef["lag"],labels)
    plt.xlabel("Lag (min)"); plt.ylabel(ylabel); plt.title(title)
    plt.tight_layout(); plt.savefig(OUTDIR/fname,dpi=150); plt.close()

effect_plot(["steps_z_t0","steps_z_t5","steps_z_t10","steps_z_t15"],
            ["0","5","10","15"],
            "effect_steps.png",
            "Steps → HR partial effects", "ΔHR (SD per SD)")
effect_plot(["HR_z_t5","HR_z_t10","HR_z_t15"],
            ["5","10","15"],
            "effect_AR.png",
            "HR autoregressive effects", "AR coeff (SD/SD)")

print(f"\n저장 완료 → {OUTDIR}\n"
      " coefs.csv, diagnostics_*.csv/png, effect_*.png\n")