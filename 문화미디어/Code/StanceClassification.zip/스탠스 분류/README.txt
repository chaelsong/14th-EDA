model_loader.py와 inference.py가 모두 있는 디렉토리에서 실행할 것

- 설치해야 하는 라이브러리
! pip install transformers torch accelerate pandas openpyxl

- import model_loader 유의사항
naver-hyperclovax/HyperCLOVAX-SEED-Text-Instruct-1.5B
해당 Huggingface 페이지에서 허가 받은 후 !huggingface-cli login 을 통해 token 입력 후 실행할 것

- 추가적인 라이브러리 임포트 후 원하는 언론사의 데이터를 df로 저장 
import inference
import pandas as pd
df = pd.read_excel('언론사_최종.xlsx')

- 다음 코드를 실행하여 스탠스 분류를 진행
from tqdm import tqdm

for i in tqdm(range(len(df)), desc="Stance Inference"):
    headline = df.loc[i, "제목"]
    features = df.loc[i, "특성추출(가중치순 상위 50개)"]
    body = df.loc[i, "본문"]
    topic_keywords = df.loc[i, "토픽 키워드"]
    sentiment_list = df.loc[i, "감성점수"]  # list of tuple 형태여야 함

    # 🔹 NaN이나 잘못된 타입 방어
    if not isinstance(sentiment_list, list):
        sentiment_list = []

    try:
        # 프롬프트 생성
        prompt = inference.stance_prompt(
            headline=headline,
            body=body,
            sentiment_list=sentiment_list,
            topic_keywords=topic_keywords,
            features=features
        )

        # LLM 응답 생성
        response = inference.generate_response(
            prompt,
            model_loader.tokenizer,
            model_loader.model
        )

        # 결과 추출
        lines = response.splitlines()
        stance = ""
        summary = ""
        for line in lines:
            if line.startswith("입장:"):
                stance = line.replace("입장:", "").strip()
            elif line.startswith("요약:"):
                summary = line.replace("요약:", "").strip()

        df.loc[i, "입장결과"] = stance
        df.loc[i, "요약결과"] = summary

    except Exception as e:
        print(f"[Error at index {i}] {e}")
        df.loc[i, "입장결과"] = ""
        df.loc[i, "요약결과"] = ""

- 결과 유의 사항
스탠스 분류에서 요약결과 자체는 질이 떨어지나 해당 작업을 통해 입장결과의 정확도가 향상되었으며 프로젝트 진행에서 필요한 데이터는 입장결과 뿐이었기에 해당 부분을 유지함. 실질적인 결과를 활용할 때에는 입장결과만을 활용하는 것을 추천함
