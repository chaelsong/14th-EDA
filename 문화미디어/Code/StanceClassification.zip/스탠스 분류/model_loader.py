from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

model_name = "naver-hyperclovax/HyperCLOVAX-SEED-Text-Instruct-1.5B"

tokenizer = AutoTokenizer.from_pretrained(model_name, use_auth_token=True)
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype=torch.float16,  # 필요 시 float32로 변경
    device_map="auto",
    use_auth_token=True
)