import textwrap
import ast
import re

def stance_prompt(headline: str, body: str, sentiment_list: list, topic_keywords: str, features: str) -> str:

    # 감성점수 총정리
    if isinstance(sentiment_list, str):
        try:
            sentiment_list = ast.literal_eval(sentiment_list)
        except:
            sentiment_list = []
    
    sentiment_list = [(str(k), str(v)) for k, v in sentiment_list]
    sentiment = dict(sentiment_list)


    # 한국어 프롬프트 구성
    prompt = f"""
    당신은 정치·국제 뉴스의 입장을 분류하는 전문가입니다.

    당신의 임무는 다음 두 가지입니다:
    (1) 해당 기사가 특정 주제에 대해 어떤 입장을 취하는지 판단하세요: [찬성 / 반대 / 없음]
    (2) 그 입장을 '50자 이내로 간결하게 요약한 문장'을 작성하세요.

    아래의 정보를 참고하세요. 주제 키워드의 값이 '할당되지 않음'이라면 주제 키워드를 참고하지 말고 답변을 대답하세요:
    - [주제 키워드]: {topic_keywords}
    - [특성]: {features}
    - [제목]: {headline}
    - [본문]: {body}
    - [감정 점수]:
    {sentiment}

    ---

    아래의 순서를 따르세요:

    1단계 – 맥락과 주제(t) 이해
    주제를 기반으로 기사에서 다루는 주요 이슈를 파악하고, 해당 이슈의 정치적/문화적 맥락을 이해하세요.

    2단계 – 주요 주장 및 시각 추출
    기사의 제목과 본문에서 핵심적으로 무엇을 주장하고 있는지, 어떤 관점을 나타내는지를 파악하세요.

    3단계 – 감정적 어조 분석
    문장 표현에서 감정적 단어, 수사적 표현(강조, 반어 등)을 확인하고, 감정적 태도를 요약하세요.
    주어진 감정 점수를 참고해 기사에서 두드러지는 감정 상태를 파악하세요.

    4단계 – 세 가지 스탠스 옵션 평가
    [찬성], [반대], [없음] 세 가지 입장 중 어떤 것과 가장 일치하는지 기사 내용과 비교해 평가하세요.

    5단계 – 논리적 추론 및 일관성 확인
    상반된 표현이나 신호가 있을 경우 논리적으로 어떤 입장이 가장 일관적인지를 추론하고,
    결론 문단 등 신뢰도 높은 단서를 우선 고려하세요.

    6단계 – 최종 결과 작성:
    - 입장을 명확하게 써주세요 (찬성 / 반대 / 중립 중 택 1)
    - 기사 입장을 50자 이하로 '요약한 문장'을 써주세요
    
    예:
    입장: 찬성
    요약: 정부의 AI 투자 확대에 긍정적 입장

    """

    return textwrap.dedent(prompt).strip()

def generate_response(prompt, tokenizer, model, max_tokens=512):
    # 모델 응답 생성
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    outputs = model.generate(
        **inputs,
        max_new_tokens=max_tokens,
        do_sample=True,
        temperature=0.7
    )

    # 전체 출력 디코딩
    decoded = tokenizer.decode(outputs[0], skip_special_tokens=True)

    # 1단계~6단계 또는 '입장:' 이후만 추출
    match = re.search(r"(입장:.*?요약:.*?)$", decoded, re.DOTALL)
    if match:
        result = match.group(0).strip()
        return textwrap.dedent(result)
    else:
        return textwrap.fill(decoded, width=100)
